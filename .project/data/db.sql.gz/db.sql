
-- Dump of TYPO3 Connection "Default"
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1765898787,1765898787,0,0,0,0,2,'{\"89ceb8a55d9e62e7844a3201b27ea2075243710b\":{\"identifier\":\"t3information\"},\"df143451ee23c178cd6722b6328fccc6e1e7ca4e\":{\"identifier\":\"docGettingStarted\"}}','cceea30f908b3871ecb9f4ed21214f969828ef2a','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(2,0,1765898673,1765898673,0,0,0,0,NULL,'default','a:5:{s:10:\"moduleData\";a:1:{s:28:\"dashboard/current_dashboard/\";s:40:\"cceea30f908b3871ecb9f4ed21214f969828ef2a\";}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:1:{s:28:\"dashboard/current_dashboard/\";s:40:\"b77217a385092e66cf8278d72a12c99282aff398\";}}',0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$NE1OSDAxSTd4Y3FFMVJLLg$FsRkESnlameXhLPBrWFGsTvYxT3bo6U2PVUTe7cT4Jo','',0,NULL,'','','',1,3,NULL,1,NULL,'',NULL,1765898785,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `nessa_social_element` int(11) NOT NULL DEFAULT 0,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,0,0,0,0,0,0,'0',1,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'Theme Nessa','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,'TYPO3, Theme Erweiterung, Sitepackage','Theme-Nessa DE - Nunc egestas, augue at pellentesque laoreet, felis eros vehicula leo, at malesuada velit leo quis pede. Sed a libero. In dui magna, posuere eget, vestibulum et, tempor auctor, justo. Aenean imperdiet. Nullam vel sem.',NULL,'','',0,1,0,'',0,'pagets__HeroLayout','pagets__DefaultLayout','EXT:sitepackage_nessa/Configuration/TSConfig/PageTs.typoscript','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,0,0,0,0,0,0,0,'0',0,NULL,0,1,1,1,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'Theme Nessa','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,'TYPO3, Theme extension, Sitepackage','Theme-Nessa EN - Nunc egestas, augue at pellentesque laoreet, felis eros vehicula leo, at malesuada velit leo quis pede. Sed a libero. In dui magna, posuere eget, vestibulum et, tempor auctor, justo. Aenean imperdiet. Nullam vel sem.',NULL,'','',0,1,0,'',0,'pagets__HeroLayout','pagets__DefaultLayout','EXT:sitepackage_nessa/Configuration/TSConfig/PageTs.typoscript','',0,0,'','','',NULL,0,'',NULL,0,''),
(3,1,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'Inhaltselemente','/inhaltselemente',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhaltselemente',0,0,'','','',NULL,0,'',NULL,0,''),
(4,3,0,0,0,0,0,0,'0',0,NULL,0,1,3,3,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'Content elements','/content-elements',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content elements',0,0,'','','',NULL,0,'',NULL,0,''),
(5,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-CTA','/inhaltselemente/ce-cta',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Call-to-Action',0,0,'','','',NULL,0,'',NULL,0,''),
(6,5,0,0,0,0,0,0,'0',0,NULL,0,1,5,5,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-CTA','/content-elements/ce-cta',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element Call-to-Action',0,0,'','','',NULL,0,'',NULL,0,''),
(7,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Divider','/inhaltselemente/ce-divider',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Linie',0,0,'','','',NULL,0,'',NULL,0,''),
(8,7,0,0,0,0,0,0,'0',0,NULL,0,1,7,7,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Divider','/content-elements/ce-divider',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element divider',0,0,'','','',NULL,0,'',NULL,0,''),
(9,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Hero','/inhaltselemente/ce-hero',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__HeroLayout','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Hero',0,0,'','','',NULL,0,'',NULL,0,''),
(10,9,0,0,0,0,0,0,'0',0,NULL,0,1,9,9,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Hero','/content-elements/ce-hero',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__HeroLayout','',NULL,'Examples of content with element Hero',0,0,'','','',NULL,0,'',NULL,0,''),
(11,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Partner','/inhaltselemente/ce-partner',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Partner',0,0,'','','',NULL,0,'',NULL,0,''),
(12,11,0,0,0,0,0,0,'0',0,NULL,0,1,11,11,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Partner','/content-elements/ce-partner',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element Partner',0,0,'','','',NULL,0,'',NULL,0,''),
(13,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Portfolio','/inhaltselemente/ce-portfolio',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Portfolio',0,0,'','','',NULL,0,'',NULL,0,''),
(14,13,0,0,0,0,0,0,'0',0,NULL,0,1,13,13,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Portfolio','/content-elements/ce-portfolio',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element Portfolio',0,0,'','','',NULL,0,'',NULL,0,''),
(15,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Portfolio mit Dateisammlung','/inhaltselemente/ce-portfolio-file-collections',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Portfolio mit Dateisammlung(en)',0,0,'','','',NULL,0,'',NULL,0,''),
(16,15,0,0,0,0,0,0,'0',0,NULL,0,1,15,15,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Portfolio with file collection(s)','/content-elements/ce-portfolio-file-collections',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element Portfolio with file collection(s)',0,0,'','','',NULL,0,'',NULL,0,''),
(17,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Shortcut','/inhaltselemente/ce-shortcut',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafter Inhalt mit den Inhaltselement Shortcut',0,0,'','','',NULL,0,'',NULL,0,''),
(18,17,0,0,0,0,0,0,'0',0,NULL,0,1,17,17,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Shortcut','/content-elements/ce-shortcut',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Example of content with element Shortcut',0,0,'','','',NULL,0,'',NULL,0,''),
(19,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Team','/inhaltselemente/ce-team',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Team',0,0,'','','',NULL,0,'',NULL,0,''),
(20,19,0,0,0,0,0,0,'0',0,NULL,0,1,19,19,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Team','/content-elements/ce-team',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element Team',0,0,'','','',NULL,0,'',NULL,0,''),
(21,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Teaser','/inhaltselemente/ce-teaser',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Teaser',0,0,'','','',NULL,0,'',NULL,0,''),
(22,21,0,0,0,0,0,0,'0',0,NULL,0,1,21,21,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Teaser','/content-elements/ce-teaser',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element Teaser',0,0,'','','',NULL,0,'',NULL,0,''),
(23,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-TeaserBackground','/inhaltselemente/ce-teaser-background',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement TeaserBackground',0,0,'','','',NULL,0,'',NULL,0,''),
(24,23,0,0,0,0,0,0,'0',0,NULL,0,1,23,23,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-TeaserBackground','/content-elements/ce-teaser-background',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element TeaserBackground',0,0,'','','',NULL,0,'',NULL,0,''),
(25,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-TeaserIcon','/inhaltselemente/ce-teaser-icon',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement TeaserIcon',0,0,'','','',NULL,0,'',NULL,0,''),
(26,25,0,0,0,0,0,0,'0',0,NULL,0,1,25,25,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-TeaserIcon','/content-elements/ce-teaser-icon',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element TeaserIcon',0,0,'','','',NULL,0,'',NULL,0,''),
(27,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Text','/inhaltselemente/ce-text',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhaltselement mit den Inhaltselement Text',0,0,'','','',NULL,0,'',NULL,0,''),
(28,27,0,0,0,0,0,0,'0',0,NULL,0,1,27,27,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Text','/content-elements/ce-text',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content element Text',0,0,'','','',NULL,0,'',NULL,0,''),
(29,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-TextMedia','/inhaltselemente/ce-textmedia',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Text & Medien',0,0,'','','',NULL,0,'',NULL,0,''),
(30,29,0,0,0,0,0,0,'0',0,NULL,0,1,29,29,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-TextMedia','/content-elements/ce-textmedia',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element Text & Media',0,0,'','','',NULL,0,'',NULL,0,''),
(31,3,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Download','/inhaltselemente/m27',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Beispielhafte Inhalte mit den Inhaltselement Downloadliste',0,0,'','','',NULL,0,'',NULL,0,''),
(32,31,0,0,0,0,0,0,'0',0,NULL,0,1,31,31,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,1,'CE-Download','/content-elements/m27',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'Examples of content with element download list',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,1,0,0,0,0,0,0,64,NULL,0,0,NULL,NULL,0,0,0,0,0,'Portfolio',0),
(2,1,0,0,0,0,0,0,64,NULL,1,1,NULL,NULL,0,0,0,0,0,'Portfolio',0),
(3,1,0,0,0,0,0,0,640,NULL,0,0,NULL,NULL,0,0,0,0,0,'Beispiel A',1),
(4,1,0,0,0,0,0,0,640,NULL,1,3,NULL,NULL,0,0,0,0,0,'Example A',1),
(5,1,0,0,0,0,0,0,768,NULL,0,0,NULL,NULL,0,0,0,0,0,'Beispiel B',1),
(6,1,0,0,0,0,0,0,768,NULL,1,5,NULL,NULL,0,0,0,0,0,'Example B',1);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(3,1,0,1,'sys_file_metadata','categories'),
(3,2,0,1,'sys_file_metadata','categories'),
(3,3,0,1,'sys_file_metadata','categories'),
(5,8,0,1,'sys_file_metadata','categories'),
(5,12,0,1,'sys_file_metadata','categories'),
(5,14,0,1,'sys_file_metadata','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1645446125,0,'/user_upload/_default/images/cole-freeman-NHXy97995Sg-unsplash.jpg','6b8a271071921ec7011482273cdca251aaab8d1f','480f9128d514071ced0c62bf01be7e789c618893','jpg','cole-freeman-NHXy97995Sg-unsplash.jpg','dca3e252e0a763ad2490fb2df0e596580b179e31',1645446125,1645436845,2832700,1,2,'image/jpeg',0,0),
(2,0,1645446125,0,'/user_upload/_default/images/daniel-santiago-46OsJaeD1F0-unsplash.jpg','99d54d57239eb835ee2c01cd876cc153ae48fe0b','480f9128d514071ced0c62bf01be7e789c618893','jpg','daniel-santiago-46OsJaeD1F0-unsplash.jpg','94b605ded2b8ac60e06035501741433179ad0ebf',1645446125,1645436845,745428,1,2,'image/jpeg',0,0),
(3,0,1645446125,0,'/user_upload/_default/images/eugene-chystiakov-TCQmflzrZRQ-unsplash.jpg','b8ea223ceb80ea7a7e14e2e6444a1f745bc173ab','480f9128d514071ced0c62bf01be7e789c618893','jpg','eugene-chystiakov-TCQmflzrZRQ-unsplash.jpg','d51c577ade7f78ecef0c18dc0655f6fc5ca4e146',1645446125,1645436845,1171362,1,2,'image/jpeg',0,0),
(4,0,1645446125,0,'/user_upload/_default/images/ruta-gudeliene-MkPt_FzqSkI-unsplash.jpg','b447331f905140b34613b82e48cb7fbae82f1e8e','480f9128d514071ced0c62bf01be7e789c618893','jpg','ruta-gudeliene-MkPt_FzqSkI-unsplash.jpg','377cf7548339553e4101eb9461c92ddc7017b116',1645446125,1645436846,5467496,1,2,'image/jpeg',0,0),
(5,0,1669360732,0,'/user_upload/_default/images/coffee/ante-samarzija-lsmu0rUhUOk-unsplash.jpg','d246e4916d1502a97898ca32f87946f15995cb4a','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','ante-samarzija-lsmu0rUhUOk-unsplash.jpg','7897296d0d14d4835a99a6a627ee163cc82a38da',1669360711,1669360229,2168009,1,2,'image/jpeg',0,0),
(6,0,1669360732,0,'/user_upload/_default/images/coffee/jeanie-de-klerk-hmLY7GiNFyE-unsplash.jpg','8ee0516c9974cbe86c5438088d0b37a3c8354e54','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','jeanie-de-klerk-hmLY7GiNFyE-unsplash.jpg','6654e1278dc31bf19bbffd460b8317f69b4e0de9',1669360711,1669360395,3079693,1,2,'image/jpeg',0,0),
(7,0,1669360732,0,'/user_upload/_default/images/coffee/jeremy-yap-jn-HaGWe4yw-unsplash.jpg','8014734e360b935d45bb0c02e9477902a96ef15c','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','jeremy-yap-jn-HaGWe4yw-unsplash.jpg','1fb2ce33d137c5ab96a18a036ad7adad86d69607',1669360711,1669360191,2406740,1,2,'image/jpeg',0,0),
(8,0,1669360732,0,'/user_upload/_default/images/coffee/nathan-dumlao-l59fmhtprIE-unsplash.jpg','0da6b318221d6d8c8e935d21fc95bc0b6ac09d96','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','nathan-dumlao-l59fmhtprIE-unsplash.jpg','5d579e7f3e59494e45cc9dc443c4a058476e70d4',1669360711,1669360566,602566,1,2,'image/jpeg',0,0),
(9,0,1669360732,0,'/user_upload/_default/images/coffee/nathan-dumlao-mgxgvwam_-c-unsplash.jpg','a4a13ceabae2207bf1893c105b426f08ce620fd7','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','nathan-dumlao-mgxgvwam_-c-unsplash.jpg','7e90c092d5a18f5c58f76ab5ae143a5a6b01ead1',1669360711,1669360299,2513388,1,2,'image/jpeg',0,0),
(10,0,1669360732,0,'/user_upload/_default/images/coffee/nathan-dumlao-nBJHO6wmRWw-unsplash.jpg','001cafebd81e36c8e3620e7577cca7e286e7dd3c','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','nathan-dumlao-nBJHO6wmRWw-unsplash.jpg','2c442c41bcf1598598c57b748792366b63fb676a',1669360711,1669360102,2057973,1,2,'image/jpeg',0,0),
(11,0,1669360732,0,'/user_upload/_default/images/coffee/olivia-anne-snyder-R5RtlMOYgX8-unsplash.jpg','b94bb2b367cd5375f9268c7b50c4b15a1ccc4ee7','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','olivia-anne-snyder-R5RtlMOYgX8-unsplash.jpg','66e7903b9ddbcfb39804ad597500fc2a31a1a06c',1669360711,1669360366,1112736,1,2,'image/jpeg',0,0),
(12,0,1669360732,0,'/user_upload/_default/images/coffee/pariwat-pannium-WLk7wdUpKXc-unsplash.jpg','3421de25f86ea6505a4f38f5e2282d8966a0e22d','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','pariwat-pannium-WLk7wdUpKXc-unsplash.jpg','e54bc8da5e68760318c4097435ef64d02a7c900d',1669360711,1669360326,736524,1,2,'image/jpeg',0,0),
(13,0,1669360732,0,'/user_upload/_default/images/coffee/samedy-nguon-DCcF-mJtTlA-unsplash.jpg','5dd36a973b4325326724d5983a0b6e5ecd2373a3','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','samedy-nguon-DCcF-mJtTlA-unsplash.jpg','d18e7fc28ebf73b228a1bcc17c3fecfd861e09c7',1669360711,1669360427,1913521,1,2,'image/jpeg',0,0),
(14,0,1669360732,0,'/user_upload/_default/images/coffee/tabitha-turner-3n3mPoGko8g-unsplash.jpg','c2198b793c46529000077b924d925e5d4c6f81cc','5fcdd6b05f77f18c38c3a5de68e97d04b609cfd1','jpg','tabitha-turner-3n3mPoGko8g-unsplash.jpg','5ededc30d14718f0b66b96e942517dfbff4c16f4',1669360711,1669360271,257710,1,2,'image/jpeg',0,0),
(15,0,1691473301,0,'/user_upload/_default/files/LoremIpsum.docx','8a9dfd5e2b3069b6ca5518fe840482889ceb659a','94358a916dfea35318cdf1268cb9756f67a407da','docx','LoremIpsum.docx','ff440d7607be56496dde021e0fe84df7ca503d7f',1691473287,1683533205,6689,1,5,'application/vnd.openxmlformats-officedocument.wordprocessingml.document',0,0),
(16,0,1691473301,0,'/user_upload/_default/files/LoremIpsum.dotx','ec0f27170e234a5fb5c8d575370fe798e882bdb4','94358a916dfea35318cdf1268cb9756f67a407da','dotx','LoremIpsum.dotx','29ab33998680fe2ab42573bf69b7dcf649354034',1691473287,1683533205,14986,1,5,'application/vnd.openxmlformats-officedocument.wordprocessingml.document',0,0),
(17,0,1691473301,0,'/user_upload/_default/files/LoremIpsum.pdf','e4d47b1dc2370b750fb94b1360c4b265402872f5','94358a916dfea35318cdf1268cb9756f67a407da','pdf','LoremIpsum.pdf','c761fbad13ceab42294314b2cab8643332f7225b',1691473287,1683533205,77123,1,5,'application/pdf',0,0),
(18,0,1691473301,0,'/user_upload/_default/files/LoremIpsum.pptx','708b224ccd992714ccea74e4508b39ec437e8016','94358a916dfea35318cdf1268cb9756f67a407da','pptx','LoremIpsum.pptx','4fad3c590a66c2addb2a824cb03a9f614e66212c',1691473287,1683533205,32184,1,5,'application/vnd.openxmlformats-officedocument.presentationml.presentation',0,0),
(19,0,1691473301,0,'/user_upload/_default/files/LoremIpsum.xlsx','56dab2549196a6f8b522eb91913ed570693075b8','94358a916dfea35318cdf1268cb9756f67a407da','xlsx','LoremIpsum.xlsx','a7bdd66944259c68fb05169ad6d54192be43707f',1691473287,1683533205,4707,1,5,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',0,0),
(20,0,1691473301,0,'/user_upload/_default/files/LoremIpsum.zip','247133175a379e723ca26eeb2d5cbfd31a1a784e','94358a916dfea35318cdf1268cb9756f67a407da','zip','LoremIpsum.zip','33b57584c6f0c9262f4129b9c3b95c34dc7679cb',1691473287,1683533205,39835,1,5,'application/zip',0,0),
(21,0,1748335130,0,'/user_upload/_default/images/people/diana-villarreal-HidnqIKfw-Q-unsplash.jpg','ada3e0417738928643be6f6c71ab585ca89e3364','266e502913364000fee3be8570077c0a47c6b2a1','jpg','diana-villarreal-HidnqIKfw-Q-unsplash.jpg','98df0546b9a5dca844b371342aaf8a7dbe5a0df6',1748335107,1748334980,7890656,1,2,'image/jpeg',0,0),
(22,0,1748335130,0,'/user_upload/_default/images/people/karsten-winegeart-GouocbGBe30-unsplash.jpg','995ffea107b8b7b36b8c26840a9c6dc79c78eb8e','266e502913364000fee3be8570077c0a47c6b2a1','jpg','karsten-winegeart-GouocbGBe30-unsplash.jpg','4ca0fbaab3223250e20bdaa5c4cd03ca54fdfbe4',1748335107,1748334970,2725449,1,2,'image/jpeg',0,0),
(23,0,1748335130,0,'/user_upload/_default/images/people/sasha-matveeva-xnS3upQYaOk-unsplash.jpg','01fa7f27c0e0d09a280e03066603c339b71df915','266e502913364000fee3be8570077c0a47c6b2a1','jpg','sasha-matveeva-xnS3upQYaOk-unsplash.jpg','fed3157fefbce80eb5cdbf4baeae3acfa8c9c2dd',1748335107,1748334948,1789246,1,2,'image/jpeg',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
INSERT INTO `sys_file_collection` VALUES
(1,15,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,0,0,'Dateisammlung 1 - mit manuell ausgewählten Dateien','static',6,NULL,0,0),
(2,15,0,0,0,0,0,0,NULL,1,1,NULL,NULL,0,0,0,0,'File collection 1 - with manuell selected files','static',6,NULL,0,0),
(3,15,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,0,0,'Dateisammlung 2 - Auswahl aus Ordner \"coffee\"','folder',0,'1:/user_upload/_default/images/coffee/',0,0),
(4,15,0,0,0,0,0,0,NULL,1,3,NULL,NULL,0,0,0,0,'File collection 2 - Selection of folder \"coffee\"','folder',0,'1:/user_upload/_default/images/coffee/',0,0),
(5,31,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,0,0,'Dateisammlung Download - Auswahl aus Ordner \"files\"','folder',0,'1:/user_upload/_default/files/',0,0),
(6,31,0,0,0,0,0,0,NULL,1,5,NULL,NULL,0,0,0,0,'File collection Download - all files from folder \"files\"','folder',0,'1:/user_upload/_default/files/',0,0);
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `nessa_portfolio_link` varchar(1024) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1645446736,1645436840,0,0,NULL,NULL,0,0,0,0,NULL,'Ein gesunder Nadelwald in dichtem Nebel.','',0,1,'Nadelwald im Nebel',6000,4000),
(2,0,1645446856,1645436840,0,0,NULL,NULL,0,0,0,0,NULL,'Ein entlaubter Baum beim Winter-Sonnenuntergang','',0,2,'Entlaubter Baum im Winter',4128,2752),
(3,0,1645446971,1645436840,0,0,NULL,NULL,0,0,0,0,NULL,'Eine Aufnahme der Meeresoberfläche mit den Umrissen eines Tieres unter Wasser','',0,3,'Meerwasser mit Tierumgrisse',2624,3936),
(4,0,1645447062,1645436840,0,0,NULL,NULL,0,0,0,0,NULL,'Ein Spaziergänger macht einen ausführlichen Spaziergang im verschneiten Wald','',0,4,'Spaziergang im Winterwald',6000,4000),
(5,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,'Viele kleine Kaffeebohnen','',0,5,'Kaffeebohnen fallen in den Kaffee',4000,6000),
(6,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,6,NULL,4480,6720),
(7,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,7,NULL,3696,5544),
(8,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,8,NULL,6185,4123),
(9,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,9,NULL,4480,6720),
(10,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,10,NULL,3087,4631),
(11,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,11,NULL,3089,2048),
(12,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,12,NULL,2810,4219),
(13,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,13,NULL,2880,3840),
(14,0,1669360728,1669360728,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,14,NULL,3000,3996),
(15,0,1691473300,1691473300,0,0,NULL,NULL,0,0,0,0,'Word Dokument','Ein Beispiel Word-Dokument','',0,15,'Praesent ut ligula non mi varius sagittis. In ac felis quis tortor malesuada pretium. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.',0,0),
(16,0,1691564829,1691564802,1,15,NULL,NULL,0,0,0,0,'Word document','Example Microsoft Word document','',0,15,'Praesent ut ligula non mi varius sagittis. In ac felis quis tortor malesuada pretium. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.',0,0),
(17,0,1691473300,1691473300,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,16,NULL,0,0),
(18,0,1691473300,1691473300,1,17,NULL,NULL,0,0,0,0,NULL,NULL,'',0,16,NULL,0,0),
(19,0,1691473300,1691473300,0,0,NULL,NULL,0,0,0,0,'PDF Dokument','Ein Beispiel PDF-Dokument','',0,17,'Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Donec vitae sapien ut libero venenatis faucibus. Praesent egestas tristique nibh.',595,842),
(20,0,1691473300,1691473300,1,19,NULL,NULL,0,0,0,0,'PDF document','Example PDF document','',0,17,'Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Donec vitae sapien ut libero venenatis faucibus. Praesent egestas tristique nibh.',595,842),
(21,0,1691473300,1691473300,0,0,NULL,NULL,0,0,0,0,'PowerPoint Dokument','Ein Beispiel PowerPoint Dokument','',0,18,'Quisque malesuada placerat nisl. Pellentesque auctor neque nec urna. Ut tincidunt tincidunt erat.',0,0),
(22,0,1691473300,1691473300,1,21,NULL,NULL,0,0,0,0,'PowerPoint document','Example PowerPoint document','',0,18,'Quisque malesuada placerat nisl. Pellentesque auctor neque nec urna. Ut tincidunt tincidunt erat.',0,0),
(23,0,1691473300,1691473300,0,0,NULL,NULL,0,0,0,0,'Excel Dokument','Ein Beispiel Excel Dokument','',0,19,'Nunc nec neque. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero..',0,0),
(24,0,1691473300,1691473300,1,23,NULL,NULL,0,0,0,0,'Excel document','Example Excel document','',0,19,'Nunc nec neque. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero..',0,0),
(25,0,1691473300,1691473300,0,0,NULL,NULL,0,0,0,0,'Zip Datei','Ein Beispiel Zip-Datei','',0,20,'Phasellus nec sem in justo pellentesque facilisis. Phasellus accumsan cursus velit. Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi.',0,0),
(26,0,1691473300,1691473300,1,25,NULL,NULL,0,0,0,0,'Zip file','Example ZIP file','',0,20,'Phasellus nec sem in justo pellentesque facilisis. Phasellus accumsan cursus velit. Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi.',0,0),
(27,0,1748335129,1748335129,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,21,NULL,6000,4000),
(28,0,1748335129,1748335129,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,22,NULL,2832,4240),
(29,0,1748335129,1748335129,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'',0,23,NULL,4570,3070);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,9,0,0,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,1,'tx_starternessa_hero_element','assets',0,'',NULL,'',0),
(2,9,0,0,0,0,0,0,NULL,NULL,0,0,0,0,2,NULL,NULL,2,'tx_starternessa_hero_element','assets',0,'',NULL,'',0),
(3,9,0,0,0,0,0,0,NULL,NULL,0,0,0,0,3,NULL,NULL,3,'tx_starternessa_hero_element','assets',0,'',NULL,'',0),
(4,9,0,0,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,4,'tx_starternessa_hero_element','assets',0,'',NULL,'',0),
(5,9,0,0,0,0,0,0,NULL,NULL,0,0,0,0,2,NULL,NULL,5,'tx_starternessa_hero_element','assets',0,'',NULL,'',0),
(6,9,0,0,0,0,0,0,NULL,NULL,0,0,0,0,3,NULL,NULL,6,'tx_starternessa_hero_element','assets',0,'',NULL,'',0),
(7,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,5,'tt_content','assets',0,'',NULL,'',0),
(8,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,2,NULL,NULL,5,'tt_content','assets',0,'',NULL,'',0),
(9,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,3,NULL,NULL,5,'tt_content','assets',0,'',NULL,'',0),
(10,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,6,'tt_content','assets',0,'',NULL,'',0),
(11,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,2,NULL,NULL,6,'tt_content','assets',0,'',NULL,'',0),
(12,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,3,NULL,NULL,6,'tt_content','assets',0,'',NULL,'',0),
(13,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,7,'tt_content','assets',0,'',NULL,'',0),
(14,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,2,NULL,NULL,7,'tt_content','assets',0,'',NULL,'',0),
(15,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,3,NULL,NULL,7,'tt_content','assets',0,'',NULL,'',0),
(16,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,8,'tt_content','assets',0,'',NULL,'',0),
(17,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,2,NULL,NULL,8,'tt_content','assets',0,'',NULL,'',0),
(18,11,0,0,0,0,0,0,NULL,NULL,0,0,0,0,3,NULL,NULL,8,'tt_content','assets',0,'',NULL,'',0),
(19,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,5,NULL,NULL,1,'sys_file_collection','files',0,'',NULL,'',0),
(20,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,6,NULL,NULL,1,'sys_file_collection','files',0,'',NULL,'',0),
(21,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,7,NULL,NULL,1,'sys_file_collection','files',0,'',NULL,'',0),
(22,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,8,NULL,NULL,1,'sys_file_collection','files',0,'',NULL,'',0),
(23,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,9,NULL,NULL,1,'sys_file_collection','files',0,'',NULL,'',0),
(24,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,10,NULL,NULL,1,'sys_file_collection','files',0,'',NULL,'',0),
(25,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,5,NULL,NULL,2,'sys_file_collection','files',0,'',NULL,'',0),
(26,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,6,NULL,NULL,2,'sys_file_collection','files',0,'',NULL,'',0),
(27,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,7,NULL,NULL,2,'sys_file_collection','files',0,'',NULL,'',0),
(28,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,8,NULL,NULL,2,'sys_file_collection','files',0,'',NULL,'',0),
(29,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,9,NULL,NULL,2,'sys_file_collection','files',0,'',NULL,'',0),
(30,15,0,0,0,0,0,0,NULL,NULL,0,0,0,0,10,NULL,NULL,2,'sys_file_collection','files',0,'',NULL,'',0),
(31,19,0,0,0,0,0,0,NULL,NULL,0,0,0,0,21,NULL,NULL,1,'tx_starternessa_team_element','assets',0,'',NULL,'{\"default\":{\"cropArea\":{\"height\":1,\"width\":0.667,\"x\":0.243,\"y\":0},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0),
(32,19,0,0,0,0,1,31,NULL,NULL,0,0,0,0,21,NULL,NULL,2,'tx_starternessa_team_element','assets',0,'',NULL,'{\"default\":{\"cropArea\":{\"height\":1,\"width\":0.667,\"x\":0.243,\"y\":0},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0),
(33,19,0,0,0,0,0,0,NULL,NULL,0,0,0,0,22,NULL,NULL,3,'tx_starternessa_team_element','assets',0,'',NULL,'{\"default\":{\"cropArea\":{\"height\":0.667,\"width\":0.9985029940119761,\"x\":0.0014970059880239522,\"y\":0.277},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0),
(34,19,0,0,0,0,1,33,NULL,NULL,0,0,0,0,22,NULL,NULL,4,'tx_starternessa_team_element','assets',0,'',NULL,'{\"default\":{\"cropArea\":{\"height\":0.537,\"width\":0.8038922155688623,\"x\":0.11976047904191617,\"y\":0.309},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0),
(35,19,0,0,0,0,0,0,NULL,NULL,0,0,0,0,23,NULL,NULL,5,'tx_starternessa_team_element','assets',0,'',NULL,'{\"default\":{\"cropArea\":{\"height\":0.7797619047619048,\"width\":0.524,\"x\":0.256,\"y\":0.12797619047619047},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0),
(36,19,0,0,0,0,1,35,NULL,NULL,0,0,0,0,23,NULL,NULL,6,'tx_starternessa_team_element','assets',0,'',NULL,'{\"default\":{\"cropArea\":{\"height\":1,\"width\":0.667,\"x\":0.243,\"y\":0},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0),
(37,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,15,NULL,NULL,29,'tt_content','media',0,'',NULL,'',0),
(38,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,16,NULL,NULL,29,'tt_content','media',0,'',NULL,'',0),
(39,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,17,NULL,NULL,29,'tt_content','media',0,'',NULL,'',0),
(40,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,18,NULL,NULL,29,'tt_content','media',0,'',NULL,'',0),
(41,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,19,NULL,NULL,29,'tt_content','media',0,'',NULL,'',0),
(42,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,20,NULL,NULL,29,'tt_content','media',0,'',NULL,'',0),
(43,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,15,NULL,NULL,30,'tt_content','media',0,'',NULL,'',0),
(44,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,16,NULL,NULL,30,'tt_content','media',0,'',NULL,'',0),
(45,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,17,NULL,NULL,30,'tt_content','media',0,'',NULL,'',0),
(46,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,18,NULL,NULL,30,'tt_content','media',0,'',NULL,'',0),
(47,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,19,NULL,NULL,30,'tt_content','media',0,'',NULL,'',0),
(48,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,20,NULL,NULL,30,'tt_content','media',0,'',NULL,'',0),
(49,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,15,NULL,NULL,31,'tt_content','media',0,'',NULL,'',0),
(50,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,16,NULL,NULL,31,'tt_content','media',0,'',NULL,'',0),
(51,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,17,NULL,NULL,31,'tt_content','media',0,'',NULL,'',0),
(52,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,18,NULL,NULL,31,'tt_content','media',0,'',NULL,'',0),
(53,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,19,NULL,NULL,31,'tt_content','media',0,'',NULL,'',0),
(54,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,20,NULL,NULL,31,'tt_content','media',0,'',NULL,'',0),
(55,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,15,NULL,NULL,32,'tt_content','media',0,'',NULL,'',0),
(56,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,16,NULL,NULL,32,'tt_content','media',0,'',NULL,'',0),
(57,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,17,NULL,NULL,32,'tt_content','media',0,'',NULL,'',0),
(58,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,18,NULL,NULL,32,'tt_content','media',0,'',NULL,'',0),
(59,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,19,NULL,NULL,32,'tt_content','media',0,'',NULL,'',0),
(60,31,0,0,0,0,0,0,NULL,NULL,0,0,0,0,20,NULL,NULL,32,'tt_content','media',0,'',NULL,'',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'core','formProtectionSessionToken:1','s:64:\"5b2e1178b75831078c6f596a8006645208bbd1d8625d93d1270a9a72f4dfaff8\";'),
(2,'core','formProtectionSessionToken:2','s:64:\"d19947b4d1a30c7c846396e821c8987071a19833a482c29251db170d6f08f051\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,0,0,0,0,0,0,0,NULL,0,'Theme-Nessa',1,3,NULL,'EXT:sitepackage_nessa/Configuration/TypoScript/',NULL,0,NULL,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `nessa_team_member_element` int(11) NOT NULL DEFAULT 0,
  `nessa_teaser_element` int(11) NOT NULL DEFAULT 0,
  `nessa_hero_element` int(11) NOT NULL DEFAULT 0,
  `nessa_social_element` int(11) NOT NULL DEFAULT 0,
  `nessa_copyright` varchar(255) NOT NULL DEFAULT '0',
  `tx_starter_ctalink` varchar(1024) NOT NULL DEFAULT '',
  `tx_starter_ctalink_text` varchar(255) NOT NULL DEFAULT '',
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,5,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','t3://page?uid=31','Mehr Infos im CE-Download','nessa_cta',0,0,'','',0,'Überschrift für das CTA Element',0,'','','','Praesent turpis. Fusce ac felis sit amet ligula pharetra condimentum. Pellentesque dapibus hendrerit tortor. Etiam iaculis nunc ac metus. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Etiam ut purus mattis mauris sodales aliquam. Sed hendrerit. Donec sodales sagittis magna. Praesent ac massa at ligula laoreet iaculis. Etiam ultricies nisi vel augue.',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(2,5,0,0,0,0,0,0,'0',0,NULL,0,1,1,1,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','t3://page?uid=31','More infos im CE-Download','nessa_cta',0,0,'','',0,'Headline of CTA element',0,'','','','Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum.',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(3,9,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',1,NULL,0,0,0,2,0,'0','','','nessa_hero',0,0,'','',0,'Beispiel CE-Hero',0,'','','',NULL,0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(4,9,0,0,0,0,0,0,'0',0,NULL,0,1,3,3,NULL,NULL,0,0,0,0,'default',1,NULL,0,0,0,0,0,'0','','','nessa_hero',0,0,'','',0,'Example CE-Hero',0,'','','',NULL,0,0,0,0,0,0,0,0,NULL,0,'',5,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(5,11,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'ctype-nessa_partner__no-bordered',0,NULL,0,0,0,0,0,'0','','','nessa_partner',0,0,'','',0,'Überschrift für das Element Partner',0,'','','Aptent taciti sociosqu','<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>',0,3,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(6,11,0,0,0,0,0,0,'0',0,NULL,0,1,5,5,NULL,NULL,0,0,0,0,'ctype-nessa_partner__no-bordered',0,NULL,0,0,0,0,0,'0','','','nessa_partner',0,0,'','',0,'Headline of CE-Partner',0,'','','','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum.</p>',0,3,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(7,11,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'ctype-nessa_partner__bordered',0,NULL,0,0,0,0,0,'0','','','nessa_partner',0,0,'','',0,'Überschrift für das Element Partner mit Rahmen',0,'','','Aptent taciti sociosqu','<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>',0,3,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(8,11,0,0,0,0,0,0,'0',0,NULL,0,1,7,7,NULL,NULL,0,0,0,0,'ctype-nessa_partner__no-bordered',0,NULL,0,0,0,0,0,'0','','','nessa_partner',0,0,'','',0,'Headline of CE-Partner with bordered logos',0,'','','','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum.</p>',0,3,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(9,13,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','nessa_portfolio',0,0,'','',0,'Überschrift für das Element Portfolio',0,'','','Aptent taciti sociosqu','<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,'3,5','',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(10,13,0,0,0,0,0,0,'0',0,NULL,0,1,9,9,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','nessa_portfolio',0,0,'','',0,'Headline of CE-Portfolio',0,'','','','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,'3,5','',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(11,15,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','nessa_portfolio_file_collections',0,0,'','',0,'Referenzen',2,'','','Ein Auszug aus unseren Referenzen','<p>Proin sapien ipsum, porta a, auctor quis, euismod ut, mi. Nunc nonummy metus. Praesent blandit laoreet nibh. Morbi mollis tellus ac sapien.&nbsp;Pellentesque auctor neque nec urna. Fusce fermentum odio nec arcu. In ac felis quis tortor malesuada pretium. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Phasellus dolor. Praesent adipiscing. Nulla sit amet est.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,'1',0,'','','',0,0),
(12,15,0,0,0,0,0,0,'0',0,NULL,0,1,11,11,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','nessa_portfolio_file_collections',0,0,'','',0,'References',2,'','','An excerpt from our references','<p>Proin sapien ipsum, porta a, auctor quis, euismod ut, mi. Nunc nonummy metus. Praesent blandit laoreet nibh. Morbi mollis tellus ac sapien.&nbsp;Pellentesque auctor neque nec urna. Fusce fermentum odio nec arcu. In ac felis quis tortor malesuada pretium. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Phasellus dolor. Praesent adipiscing. Nulla sit amet est.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,'2',0,'','','',0,0),
(13,15,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','nessa_portfolio_file_collections',0,0,'','',0,'Referenzen',2,'','','Ein Auszug aus unseren Referenzen','<p>Proin sapien ipsum, porta a, auctor quis, euismod ut, mi. Nunc nonummy metus. Praesent blandit laoreet nibh. Morbi mollis tellus ac sapien.&nbsp;Pellentesque auctor neque nec urna. Fusce fermentum odio nec arcu. In ac felis quis tortor malesuada pretium. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Phasellus dolor. Praesent adipiscing. Nulla sit amet est.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,'3',0,'','','',0,0),
(14,15,0,0,0,0,0,0,'0',0,NULL,0,1,13,13,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','nessa_portfolio_file_collections',0,0,'','',0,'References',2,'','','An excerpt from our references','<p>Proin sapien ipsum, porta a, auctor quis, euismod ut, mi. Nunc nonummy metus. Praesent blandit laoreet nibh. Morbi mollis tellus ac sapien.&nbsp;Pellentesque auctor neque nec urna. Fusce fermentum odio nec arcu. In ac felis quis tortor malesuada pretium. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Cras ultricies mi eu turpis hendrerit fringilla.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum. Phasellus dolor. Praesent adipiscing. Nulla sit amet est.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,'4',0,'','','',0,0),
(15,17,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','shortcut',0,0,'','',0,'Interner Titel',0,'','','',NULL,0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(16,17,0,0,0,0,0,0,'0',0,NULL,0,1,15,15,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','shortcut',0,0,'','',0,'No visible header',0,'','','',NULL,0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(17,19,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,3,0,0,0,'0','','','nessa_team',0,0,'','',0,'Überschrift für das Element Team',0,'','','Ut enim ad minim veniam','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(18,19,0,0,0,0,0,0,'0',0,NULL,0,1,17,17,NULL,NULL,0,0,0,0,'default',0,NULL,0,3,0,0,0,'0','','','nessa_team',0,0,'','',0,'Headline of CE-Team',0,'','','Ut enim ad minim veniam','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(19,27,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'Überschrift für den nachfolgenden Textabschnitt',2,'','','','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(20,27,0,0,0,0,0,0,'0',0,NULL,0,1,19,19,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'Headline for the following text section',2,'','','','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(21,27,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'Überschrift in Level 3',3,'','','Untergeordnete Überschrift','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(22,27,0,0,0,0,0,0,'0',0,NULL,0,1,21,21,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'Main heading in level 3',3,'','','Subheading','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(23,27,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'Hauptüberschrift in Level 2',2,'','','Untergeordnete Überschrift ohne Levelauszeichnung','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(24,27,0,0,0,0,0,0,'0',0,NULL,0,1,23,23,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'Main heading in level 2',2,'','','Subheading without level markup','<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(25,27,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','https://google.com/?q=typo3 - - \"Mit Google nach TYPO3 suchen\"','Suchergebnisse auf Google nach TYPO3','text',0,0,'','',0,'Ut tincidunt tincidunt erat',2,'','','','<p>Pellentesque habitant <strong>morbi tristique senectus</strong> et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque <em>dapibus hendrerit tortor</em>.</p>\r\n<ul> 	<li>Aenean vulputate eleifend tellus</li> 	<li>Nam commodo suscipit quam</li> 	<li>Nulla facilisi</li> 	<li>Fusce ac felis sit amet ligula pharetra condimentum</li> </ul>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<ol> 	<li>Donec vitae orci sed dolor rutrum auctor</li> 	<li>In hac habitasse platea dictumst</li> 	<li>Ut tincidunt tincidunt erat</li> 	<li>Donec vitae orci sed dolor rutrum auctor.</li> </ol>\r\n<p class=\"text-center\">Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(26,27,0,0,0,0,0,0,'0',0,NULL,0,1,25,25,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','https://google.com/?q=typo3 - - \"Search with Google for TYPO3\"','Search results on Google for TYPO3','text',0,0,'','',0,'Ut tincidunt tincidunt erat',2,'','','','<p>Pellentesque habitant <strong>morbi tristique senectus</strong> et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque <em>dapibus hendrerit tortor</em>.</p>\r\n<ul> 	<li>Aenean vulputate eleifend tellus</li> 	<li>Nam commodo suscipit quam</li> 	<li>Nulla facilisi</li> 	<li>Fusce ac felis sit amet ligula pharetra condimentum</li> </ul>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<ol> 	<li>Donec vitae orci sed dolor rutrum auctor</li> 	<li>In hac habitasse platea dictumst</li> 	<li>Ut tincidunt tincidunt erat</li> 	<li>Donec vitae orci sed dolor rutrum auctor.</li> </ol>\r\n<p class=\"text-center\">Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(27,27,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'',2,'','','','<p><strong>Dieser Textabschnitt hat keine Überschrift im Modul!</strong></p>\r\n<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(28,27,0,0,0,0,0,0,'0',0,NULL,0,1,27,27,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','text',0,0,'','',0,'',2,'','','','<p><strong>This text section has no module headline!</strong></p>\r\n<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec venenatis vulputate lorem. Sed fringilla mauris sit amet nibh. Pellentesque dapibus hendrerit tortor.</p>\r\n<p>Aenean vulputate eleifend tellus. Nam commodo suscipit quam. Nulla facilisi. Fusce ac felis sit amet ligula pharetra condimentum. Curabitur vestibulum aliquam leo.</p>\r\n<p>Praesent nec nisl a purus blandit viverra. Etiam feugiat lorem non metus. In turpis. Curabitur suscipit suscipit tellus. Phasellus dolor.</p>\r\n<p>Donec vitae orci sed dolor rutrum auctor. In hac habitasse platea dictumst. Ut tincidunt tincidunt erat. Donec vitae orci sed dolor rutrum auctor. Praesent porttitor, nulla vitae posuere iaculis, arcu nisl dignissim dolor, a pretium mi sem ut ipsum.</p>',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(29,31,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','starter_m27_download',0,0,'','',0,'Download',2,'','','Dokumente zum Download',NULL,0,0,0,0,0,0,0,0,NULL,0,'',5,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(30,31,0,0,0,0,0,0,'0',0,NULL,0,1,29,29,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','starter_m27_download',0,0,'','',0,'Download',2,'','','Documents for download',NULL,0,0,0,0,0,0,0,0,NULL,0,'',5,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(31,31,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','starter_m27_download',0,0,'','',0,'Download',2,'','','Dokumente zum Download','<p>Morbi vestibulum volutpat enim. Etiam rhoncus. Nam commodo suscipit quam. Donec venenatis vulputate lorem.</p>\r\n<p>Suspendisse feugiat. Cras risus ipsum, faucibus ut, ullamcorper id, varius ac, leo. Morbi mattis ullamcorper velit. Vestibulum facilisis, purus nec pulvinar iaculis, ligula mi congue nunc, vitae euismod ligula urna in dolor.</p>',0,0,0,0,0,0,0,0,NULL,0,'',5,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(32,31,0,0,0,0,0,0,'0',0,NULL,0,1,31,31,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','starter_m27_download',0,0,'','',0,'Download',2,'','','Documents for download','<p>Morbi vestibulum volutpat enim. Etiam rhoncus. Nam commodo suscipit quam. Donec venenatis vulputate lorem.</p>\r\n<p>Suspendisse feugiat. Cras risus ipsum, faucibus ut, ullamcorper id, varius ac, leo. Morbi mattis ullamcorper velit. Vestibulum facilisis, purus nec pulvinar iaculis, ligula mi congue nunc, vitae euismod ligula urna in dolor.</p>',0,0,0,0,0,0,0,0,NULL,0,'',5,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0),
(33,31,0,0,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','starter_m27_download',0,0,'','',0,'Download',2,'','','Dokumente zum Download von einer Dateisammmlung','',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,'5',1,'','','',1,0),
(34,31,0,0,0,0,0,0,'0',0,NULL,0,1,33,33,NULL,NULL,0,0,0,0,'default',0,NULL,0,0,0,0,0,'0','','','starter_m27_download',0,0,'','',0,'Download',2,'','','Documents for download','',0,0,0,0,0,0,0,0,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,'6',1,'','','',1,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  `update_comment` longtext DEFAULT NULL,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_starternessa_hero_element`
--

DROP TABLE IF EXISTS `tx_starternessa_hero_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_starternessa_hero_element` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content_record` int(11) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `assets` int(11) NOT NULL DEFAULT 0,
  `bodytext` text DEFAULT NULL,
  `ctalink` varchar(1024) NOT NULL DEFAULT '',
  `ctalink_text` varchar(255) NOT NULL DEFAULT '',
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_starternessa_hero_element`
--

LOCK TABLES `tx_starternessa_hero_element` WRITE;
/*!40000 ALTER TABLE `tx_starternessa_hero_element` DISABLE KEYS */;
INSERT INTO `tx_starternessa_hero_element` VALUES
(1,9,0,0,0,0,0,0,1,0,0,0,NULL,0,NULL,0,0,0,0,3,'Suspendisse eu ligula',1,'Sed hendrerit. Sed hendrerit. Praesent egestas tristique nibh. Nulla porta dolor. Morbi vestibulum volutpat enim. Nullam dictum felis eu pede mollis pretium. Fusce neque. Nulla porta dolor.','t3://page?uid=20','Etiam ultricies nisi',''),
(2,9,0,0,0,0,0,0,1,0,0,0,NULL,0,NULL,0,0,0,0,3,'Maecenas nec odio',1,'Donec vitae sapien ut libero venenatis faucibus. In hac habitasse platea dictumst. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi.','','',''),
(3,9,0,0,0,0,0,0,3,0,0,0,NULL,0,NULL,0,0,0,0,3,'Nullam quis ante',1,NULL,'','',''),
(4,9,0,0,0,0,0,0,1,1,1,0,NULL,0,NULL,0,0,0,0,4,'Suspendisse eu ligula',1,'Sed hendrerit. Sed hendrerit. Praesent egestas tristique nibh. Nulla porta dolor. Morbi vestibulum volutpat enim. Nullam dictum felis eu pede mollis pretium. Fusce neque. Nulla porta dolor.','t3://page?uid=20','Etiam ultricies nisi',''),
(5,9,0,0,0,0,0,0,2,1,2,0,NULL,0,NULL,0,0,0,0,4,'Maecenas nec odio',1,'Donec vitae sapien ut libero venenatis faucibus. In hac habitasse platea dictumst. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi.','','',''),
(6,9,0,0,0,0,0,0,3,1,3,0,NULL,0,NULL,0,0,0,0,4,'Maecenas nec odio',1,NULL,'','','');
/*!40000 ALTER TABLE `tx_starternessa_hero_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_starternessa_social_element`
--

DROP TABLE IF EXISTS `tx_starternessa_social_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_starternessa_social_element` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `pages_record` int(11) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(30) NOT NULL DEFAULT '',
  `social_link` varchar(1024) NOT NULL DEFAULT '',
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_starternessa_social_element`
--

LOCK TABLES `tx_starternessa_social_element` WRITE;
/*!40000 ALTER TABLE `tx_starternessa_social_element` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_starternessa_social_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_starternessa_team_element`
--

DROP TABLE IF EXISTS `tx_starternessa_team_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_starternessa_team_element` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content_record` int(11) NOT NULL DEFAULT 0,
  `realname` varchar(255) NOT NULL DEFAULT '',
  `company_position` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(1024) NOT NULL DEFAULT '',
  `assets` int(11) NOT NULL DEFAULT 0,
  `bodytext` text DEFAULT NULL,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_starternessa_team_element`
--

LOCK TABLES `tx_starternessa_team_element` WRITE;
/*!40000 ALTER TABLE `tx_starternessa_team_element` DISABLE KEYS */;
INSERT INTO `tx_starternessa_team_element` VALUES
(1,19,0,0,0,0,0,0,1,0,0,0,NULL,0,NULL,0,0,0,0,17,'Diana Villarreal','Example CEO','example@mail.com',1,NULL,''),
(2,19,0,0,0,0,0,0,1,1,1,0,NULL,0,NULL,0,0,0,0,18,'Diana Villarreal','Example CEO','example@mail.com',1,NULL,''),
(3,19,0,0,0,0,0,0,514,0,0,0,NULL,0,NULL,0,0,0,0,17,'Karsten Winegeart','Example CEO','example@mail.com',1,NULL,''),
(4,19,0,0,0,0,0,0,1,1,3,0,NULL,0,NULL,0,0,0,0,18,'Karsten Winegeart','Example CEO','example@mail.com',1,NULL,''),
(5,19,0,0,0,0,0,0,515,0,0,0,NULL,0,NULL,0,0,0,0,17,'Sasha Matveeva','Example CEO','example@mail.com',1,NULL,''),
(6,19,0,0,0,0,0,0,1,1,5,0,NULL,0,NULL,0,0,0,0,18,'Sasha Matveeva','Example CEO','example@mail.com',1,NULL,'');
/*!40000 ALTER TABLE `tx_starternessa_team_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_starternessa_teaser_element`
--

DROP TABLE IF EXISTS `tx_starternessa_teaser_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_starternessa_teaser_element` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content_record` int(11) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(30) NOT NULL DEFAULT '',
  `assets` int(11) NOT NULL DEFAULT 0,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `link_text` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_starternessa_teaser_element`
--

LOCK TABLES `tx_starternessa_teaser_element` WRITE;
/*!40000 ALTER TABLE `tx_starternessa_teaser_element` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_starternessa_teaser_element` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-16 16:28:21
